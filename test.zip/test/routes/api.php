<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\TagController;
use App\Http\Controllers\UserController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Public routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// Protected routes (require authentication)
Route::middleware('auth:sanctum')->group(function () {
    // User routes
    Route::get('/user', function (Request $request) {
        return $request->user()->loadCount('posts', 'comments');
    });
    Route::post('/logout', [AuthController::class, 'logout']);

    // Post routes
    Route::apiResource('posts', PostController::class);
 //   Route::apiResource('posts.comments', CommentController::class);

    
    // Comment routes (nested under posts)
    Route::prefix('posts/{post}')->group(function () {
        Route::get('/comments', [CommentController::class, 'index']);
        Route::post('/comments', [CommentController::class, 'store']);
       //  Route::post('/comments', [CommentController::class, 'destroy']);
    });



    
    // Standalone comment routes
    Route::apiResource('comments', CommentController::class)->only(['index', 'update', 'destroy']);
    
    // Tag routes
    Route::apiResource('tags', TagController::class);
    
    // Tag-Post relationships
    Route::prefix('tags/{tag}')->group(function () {
        Route::get('/posts', [TagController::class, 'getPosts']);
    });
});