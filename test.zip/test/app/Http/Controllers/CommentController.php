<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Post;

class CommentController extends Controller
{
    
  public function index(Post $post){
    return $post->comments()->with('user')->get();
  }

  public function store(Request $req){
    $data = $req->validate(['post_id'=>'required|exists:posts,id','body'=>'required|string']);
    $data['user_id'] = auth()->id();
    return response()->json(Comment::create($data), 201);
  }

  public function update(Request $req, Comment $comment){
    $this->authorize('update',$comment);
    $body = $req->validate(['body'=>'required|string']);
    $comment->update($body);
    return $comment;
  }

  public function destroy(Comment $comment){
    $this->authorize('delete',$comment);
    $comment->delete();
    return response()->noContent();
  }
}


