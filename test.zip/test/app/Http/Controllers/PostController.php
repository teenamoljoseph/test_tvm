<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Tag;

class PostController extends Controller {
  public function index(){
    return Post::with(['user','comments.user','tags'])->get();
  }

  public function store(Request $req){
    $data = $req->validate([
      'title'=>'required|string|max:255',
      'body'=>'required|string',
      'tags'=>'array',
      'tags.*'=>'string'
    ]);
    $data['user_id'] = auth()->id();
   
    $post = Post::create($data);
    if(isset($data['tags'])){
      $tagIds = collect($data['tags'])->map(fn($t)=>Tag::firstOrCreate(['name'=>$t])->id);
      $post->tags()->sync($tagIds);
    }
    return response()->json($post->load(['tags']), 201);
  }

  public function show(Post $post){
    return $post->load(['user','comments.user','tags']);
  }

  public function update(Request $req, Post $post){
    $this->authorize('update',$post);
    $data = $req->validate(['title'=>'string','content'=>'string','tags'=>'array','tags.*'=>'string']);
    $post->update($req->only(['title','content']));
    if(isset($data['tags'])){
      $tagIds = collect($data['tags'])->map(fn($t)=>Tag::firstOrCreate(['name'=>$t])->id);
      $post->tags()->sync($tagIds);
    }
    return $post->fresh()->load(['tags']);
  }

  public function destroy(Post $post){
    $this->authorize('delete',$post);
    $post->delete();
    return response()->noContent();
  }
}

