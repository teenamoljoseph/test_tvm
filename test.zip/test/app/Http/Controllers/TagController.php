<?php

namespace App\Http\Controllers;


use App\Http\Controllers\Controller;
use App\Models\Tag;
use Illuminate\Http\Request;

class TagController extends Controller
{
    public function __construct()
    {
        // Require authentication except for index and show
        $this->middleware('auth:sanctum')->except(['index', 'show']);
    }

    // List all tags
    public function index()
    {
        $tags = Tag::all();
        return response()->json($tags);
    }

    // Show a single tag by id with posts attached
    public function show($id)
    {
        $tag = Tag::with('posts')->find($id);

        if (!$tag) {
            return response()->json(['message' => 'Tag not found'], 404);
        }

        return response()->json($tag);
    }

    // Create a new tag
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|unique:tags,name|max:50',
        ]);

        $tag = Tag::create([
            'name' => $request->name,
        ]);

        return response()->json($tag, 201);
    }

    // Update a tag
    public function update(Request $request, $id)
    {
        $tag = Tag::find($id);

        if (!$tag) {
            return response()->json(['message' => 'Tag not found'], 404);
        }

        $request->validate([
            'name' => 'required|string|unique:tags,name,' . $id . '|max:50',
        ]);

        $tag->update([
            'name' => $request->name,
        ]);

        return response()->json($tag);
    }

    // Delete a tag
    public function destroy($id)
    {
        $tag = Tag::find($id);

        if (!$tag) {
            return response()->json(['message' => 'Tag not found'], 404);
        }

        $tag->posts()->detach(); // Remove relationships with posts first
        $tag->delete();

        return response()->json(['message' => 'Tag deleted']);
    }

    public function getPosts($tagId)
{
    $tag = Tag::with('posts')->find($tagId);

    if (!$tag) {
        return response()->json(['message' => 'Tag not found'], 404);
    }

    return response()->json($tag->posts);
}

}
