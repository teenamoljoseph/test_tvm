<?php

namespace App\Http\Controllers;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Auth;

use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function register(Request $r){
  $data = $r->validate([
    'name'=>'required',
    'email'=>'required|email|unique:users',
    'password'=>'required|min:6'
  ]);
  $user = User::create([
    'name'     => $data['name'],
    'email'    => $data['email'],
    'password' => Hash::make($data['password']),
]);

  $token = $user->createToken('auth-token')->plainTextToken;
  return response()->json([
            'message' => 'User registered successfully',
            'user' => $user,
            'access_token' => $token,
            'token_type' => 'Bearer'
        ], 201);

}

public function login(Request $r){
  $data = $r->validate(['email'=>'required|email','password'=>'required']);
  if (!Auth::attempt($data)) {
    return response()->json(['message'=>'Invalid credentials'], 401);
  }
  $user = Auth::user();
  $token = $user->createToken('auth-token')->plainTextToken;
  return response()->json([ 'message' => 'Welcome','user'=>$user,'token'=>$token]);
}

public function logout(Request $r){
  $r->user()->currentAccessToken()->delete();
  return response()->json(['message'=>'Logged out']);
}

}
