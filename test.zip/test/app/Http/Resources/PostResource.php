<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PostResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
  public function toArray(Request $r){
  return [
    'id'=>$this->id,
    'title'=>$this->title,
    'content'=>$this->content,
    'author'=>new UserResource($this->whenLoaded('user')),
    'comments'=>CommentResource::collection($this->whenLoaded('comments')),
    'tags'=>$this->tags->pluck('name'),
    'comments_count'=>$this->whenCounted('comments'),
  ];
}

}
